"""
Read file into texts and calls.
It's ok if you don't understand how to read files.
"""
import csv
with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)


"""
TASK 1:
How many different telephone numbers are there in the records?
Print a message:
"There are <count> different telephone numbers in the records."
"""

# Create a list containing all unique phone numbers across texts and calls records
numbers = []
for row in texts:
    if row[0] not in texts:
        numbers.append(row[0])
    if row[1] not in texts:
        numbers.append(row[1])

for row in calls:
    if row[0] not in texts:
        numbers.append(row[0])
    if row[1] not in texts:
        numbers.append(row[1])

# Calculate length of the list i.e., number of unique phone numbers
length=len(numbers)

# Print results
print("There are", length, "different telephone numbers in the records")
