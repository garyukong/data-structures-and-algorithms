"""
Read file into texts and calls.
It's ok if you don't understand how to read files
"""
import csv
with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)

"""
TASK 2: Which telephone number spent the longest time on the phone
during the period? Don't forget that time spent answering a call is
also time spent on the phone.
Print a message:
"<telephone number> spent the longest time, <total time> seconds, on the phone during
September 2016.".
"""

# Create a dictionary containing all phone numbers calls. Sum durations
calldir = {}
for row in calls:
    if row[0] not in calls: # Phone numbers calling out and cumulative durations
        calldir[row[0]] = row[3]
    else:
        calldir[row[0]] += row[3]

    if row[1] not in calls: # Phone numbers receiving calls and cumulative durations
        calldir[row[1]] = row[3]
    else:
        calldir[row[1]] += row[3]

# Retrieve maximum value (cumulative duration of calls) and key (phone number) with longest time on the phone
maxvalue = max(calldir.values()) # maximum value
maxkey = max(calldir, key=calldir.get) # key with maximum value

# Print a message
print(maxkey, "spent the longest time,", maxvalue, "seconds, on the phone during September 2016")